/**
    Copyright 2016 Joe Pecore  
   
     Voice Sports Games 
   
       
     
     
     
 */

/**
 * This Skill was based on the History Buff example skill which demonstrates how
 * to create a Lambda function for handling Alexa Skill requests that: - Web
 * service: communicate with an external web service to get events for specified
 * days in history (Mediawiki API) - Pagination: after obtaining a list of
 * events, read a small subset of events and wait for user prompt to read the
 * next subset of events by maintaining session state - Dialog and Session
 * state: Handles two models, both a one-shot ask and tell model, and a
 * multi-turn dialog model. - SSML: Using SSML tags to control how Alexa renders
 * the text-to-speech.
 *  
 * 
 * 
 * /** App ID for the skill
 */
var APP_ID = 'amzn1.ask.skill.'; // brush teeth
 

/**
 * The AlexaSkill Module that has the AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * BrushTeethSkill is a child of AlexaSkill. To read more about inheritance in
 * JavaScript, see the link below.
 * 
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var BrushTeethSkill = function() {
	AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
BrushTeethSkill.prototype = Object.create(AlexaSkill.prototype);
BrushTeethSkill.prototype.constructor = BrushTeethSkill;
BrushTeethSkill.prototype.eventHandlers.onSessionStarted = function(
		sessionStartedRequest, session) {
	console.log("BrushTeethSkill onSessionStarted requestId: "
			+ sessionStartedRequest.requestId + ", sessionId: "
			+ session.sessionId);

	// any session init logic would go here
	
	
};



/* global variables */
 
/* onLaunch */
BrushTeethSkill.prototype.eventHandlers.onLaunch = function(launchRequest,
		session, response) {
	console.log("BrushTeethSkill onLaunch requestId: " + launchRequest.requestId
			+ ", sessionId: " + session.sessionId);
	getWelcomeResponse(response);
};

/* onSessionEnded */
BrushTeethSkill.prototype.eventHandlers.onSessionEnded = function(
		sessionEndedRequest, session) {
	console.log("onSessionEnded requestId: " + sessionEndedRequest.requestId
			+ ", sessionId: " + session.sessionId);
	// any session cleanup logic would go here
	
};

/* intents */
BrushTeethSkill.prototype.intentHandlers = {
	 
		"brushTeethIntent" : function(intent, session, response) {
			console.log("brushTeethIntent   requestId: " + launchRequest.requestId
					+ ", sessionId: " + session.sessionId);
			getWelcomeResponse(response);
		},
		
		
	"AMAZON.HelpIntent" : function(intent, session, response) {
		var speechText =  "Just ask alexa to open Brush Teeth ";
		var repromptText = "I did not understand you. The only command is open Brush Teeth. what would you  like to do?";
		var speechOutput = {
			speech : speechText,
			type : AlexaSkill.speechOutputType.PLAIN_TEXT
		};
		var repromptOutput = {
			speech : repromptText,
			type : AlexaSkill.speechOutputType.PLAIN_TEXT
		};
		response.ask(speechOutput, repromptOutput);
	},

	"AMAZON.StopIntent" : function(intent, session, response) {
		var speechOutput = {
			speech : "Good bye!",
			type : AlexaSkill.speechOutputType.PLAIN_TEXT
		};
		response.tell(speechOutput);
	},

	"AMAZON.CancelIntent" : function(intent, session, response) {
		var speechOutput = {
			speech : "Good bye!",
			type : AlexaSkill.speechOutputType.PLAIN_TEXT
		};
		response.tell(speechOutput);
	}
};

/**
 * Function to handle the onLaunch skill behavior
 */

function getWelcomeResponse(response) {
	// If we wanted to initialize the session to have some attributes we could
	// add those here.
	 
	var repromptText = "I did not understand. What did you say?";
	var speechText = "<p>Start brushing your teeth now. I will tell you when two minutes is over.</p>";
	var cardOutput = "";
	// If the user either does not reply to the welcome message or says
	// something that is not
	// understood, they will be prompted again with this text.

	var speechOutput = {
		speech : "<speak>" + speechText + "</speak>",
		type : AlexaSkill.speechOutputType.SSML
	};
	var repromptOutput = {
		speech : repromptText,
		type : AlexaSkill.speechOutputType.PLAIN_TEXT
	};
	response.tell(speechOutput, repromptOutput);
}
 

function buildSpeechletResponseWithoutCard(output, repromptText,shouldEndSession) {
	return {
		outputSpeech : {
			type : "PlainText",
			text : output
		},
		reprompt : {
			outputSpeech : {
				type : "PlainText",
				text : repromptText
			}
		},
		shouldEndSession : shouldEndSession
	};
}
  

// Create the handler that responds to the Alexa Request.
exports.handler = function(event, context) {
	// Create an instance of the BrushTeethSkill.
	var skill = new BrushTeethSkill();
	skill.execute(event, context);
};